# -*- coding: utf-8 -*-
"""
#Small automation Python script- Auto testing web

#1. Test cases: 10 test cases are defined to test different parts of the NVIDIA website.
#2.Selenium: Used to navigate to the NVIDIA website and ensure each page loads successfully.
#3. Failure log: Record a failure log when a test fails so that it can be displayed in the report.
#4. Execution time: Each test case records its execution time.
#5. Summary of results: Calculate total execution time, pass rate, and failure rate.
#6. HTML report: Generate an HTML report, including the test results. The passing status is displayed in blue, the failure is displayed in red, and the corresponding failure log is displayed.
#7. Bar Chart: Plot pass and fail bar charts using Matplotlib.
#8. Automatically calculate the pass rate and failure rate: In your program, it may be that the status uses the Chinese characters "pass" and "fail", causing the status to be incorrectly recognized during calculation. You can try to replace the status value in results with "pass" and "fail", and then convert it to Chinese in the HTML display.
#9. Status display font color: The calculation of pass rate and failure rate relies on correct string matching. To ensure correct calculation, will modify the status display part and display the font color correctly.
#10.Incomplete display of the histogram: The size or proportion of the image may cause incomplete display. The proportion and size of the graph will be adjusted to fix this problem.

#Created by Tommas Huang 
#Created date: 2024-10-02
"""

import time
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
import pandas as pd
import matplotlib.pyplot as plt
import base64
from io import BytesIO

# 定義測試案例
test_cases = [
    {"id": "TC001", "description": "檢查介紹頁面是否可訪問", "url": "https://www.nvidia.com/en-us/industries/"},
    {"id": "TC002", "description": "檢查解決方案頁面是否可訪問", "url": "https://www.nvidia.com/en-us/solutions/"},
    {"id": "TC003", "description": "檢查軟體頁面是否可訪問", "url": "https://www.nvidia.com/en-us/software/"},
    {"id": "TC004", "description": "檢查產品頁面是否可訪問", "url": "https://www.nvidia.com/en-us/products/"},
    {"id": "TC005", "description": "檢查資源頁面是否可訪問", "url": "https://www.nvidia.com/en-us/resources/"},
    {"id": "TC006", "description": "檢查 AI 行業解決方案頁面", "url": "https://www.nvidia.com/en-us/industries/ai/"},
    {"id": "TC007", "description": "檢查自駕車解決方案頁面", "url": "https://www.nvidia.com/en-us/solutions/self-driving/"},
    {"id": "TC008", "description": "檢查深度學習軟體頁面", "url": "https://www.nvidia.com/en-us/software/deep-learning/"},
    {"id": "TC009", "description": "檢查遊戲產品頁面", "url": "https://www.nvidia.com/en-us/products/gaming/"},
    {"id": "TC010", "description": "檢查資源下載區頁面", "url": "https://www.nvidia.com/en-us/resources/downloads/"}
]


results = []
total_start_time = time.time()

# 設置 Selenium WebDriver
chrome_options = Options()
chrome_options.add_argument("--headless")  # 無頭模式
chrome_options.add_argument("--no-sandbox")  # 禁用沙盒
chrome_options.add_argument("--disable-dev-shm-usage")  # 禁用 /dev/shm
chrome_options.add_argument("--remote-debugging-port=9222")  # 遠端調試埠

# 使用 ChromeDriver 的服務
service = Service('/usr/bin/chromedriver')
driver = webdriver.Chrome(service=service, options=chrome_options)

for test_case in test_cases:
    start_time = time.time()
    fail_log = ""
    try:
        driver.get(test_case["url"])
        time.sleep(2)  # 等待頁面載入
        assert "NVIDIA" in driver.title  #  確保頁面標題包含 NVIDIA
        
        execution_time = time.time() - start_time
        results.append({"id": test_case["id"], "description": test_case["description"], "status": "Pass", "execution_time": execution_time, "fail_log": ""})
    except Exception as e:
        execution_time = time.time() - start_time
        fail_log = str(e)  # 失敗日誌
        results.append({"id": test_case["id"], "description": test_case["description"], "status": "Fail", "execution_time": execution_time, "fail_log": fail_log})

# 關閉驅動
driver.quit()

# 計算統計資料
total_execution_time = time.time() - total_start_time
pass_count = sum(1 for result in results if result["status"] == "Pass")
fail_count = sum(1 for result in results if result["status"] == "Fail")
total_tests = len(results)
pass_rate = (pass_count / total_tests) * 100
fail_rate = (fail_count / total_tests) * 100

# 建立结果的 DataFrame
df = pd.DataFrame(results)

# 生成柱狀圖
plt.rcParams['font.family'] = 'Noto Sans CJK'  # 設置字體為中文字體
labels = ['Pass', 'Fail']
values = [pass_count, fail_count]
plt.bar(labels, values, color=['blue', 'red'])
plt.title('Test Yield Histogram')
plt.ylabel('Number of Tests')
plt.ylim(0, max(values) + 1)

# 將圖像保存到內存中的字節緩衝區
buffer = BytesIO()
plt.savefig(buffer, format='png')
buffer.seek(0)
img_base64 = base64.b64encode(buffer.read()).decode('utf-8')
buffer.close()
plt.close()

# 生成 HTML 报告
report_html = f"""
<!DOCTYPE html>
<html lang="zh-Hant">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NVIDIA 官網測試報告</title>
    <style>
        body {{ font-family: Arial, sans-serif; }}
        table {{ border-collapse: collapse; width: 100%; }}
        th, td {{ border: 1px solid #ddd; padding: 8px; }}
        th {{ background-color: #f2f2f2; }}
        .pass {{ color: blue; }}
        .fail {{ color: red; }}
    </style>
</head>
<body>
    <h1>NVIDIA 官網測試報告</h1>
    <p>總執行時間: {total_execution_time:.2f} 秒</p>
    <p>通過率: {pass_rate:.2f}%</p>
    <p>失敗率: {fail_rate:.2f}%</p>
    <h2>測試結果</h2>
    <table>
        <tr>
            <th>測試案例 ID</th>
            <th>描述</th>
            <th>狀態</th>
            <th>執行時間 (秒)</th>
            <th>失敗日誌</th>
        </tr>
"""

for index, row in df.iterrows():
    status_class = "pass" if row['status'] == "Pass" else "fail"
    fail_log_display = row['fail_log'] if row['fail_log'] else "無"
    report_html += f"""
        <tr>
            <td>{row['id']}</td>
            <td>{row['description']}</td>
            <td class="{status_class}">{row['status']}</td>
            <td>{row['execution_time']:.2f}</td>
            <td>{fail_log_display}</td>
        </tr>
    """

report_html += f"""
    </table>
    <h2>良率柱狀圖</h2>
    <img src="data:image/png;base64,{img_base64}" alt="良率柱狀圖">
</body>
</html>
"""

# 保存 HTML 報告
timestamp = time.strftime("%Y%m%d_%H%M%S")
with open(f"nvidia_test_report_{timestamp}.html", "w", encoding='utf-8') as f:
    f.write(report_html)

print("測試報告已成功生成")
